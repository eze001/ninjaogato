<template>
  <div class="hello">
    <h1>{{ msg }}</h1>
    <img v-if="mostrar1" id="dibujo" alt="dibujo" src="./ninja.jpg">
    <img v-if="mostrar2" id="dibujo" alt="dibujo" src="./gato.jpg">
    <button v-on:click="f1">Mostrar Ninja</button>
    <button v-on:click="f2" >Mostrar Gato</button>
  </div>
</template>

<script>
export default {
  name: 'HelloWorld',
  props: {
    msg: String
  },
  data:function(){
    return{
      mostrar1:true,
      mostrar2:false
    };
  },
  methods:{
    f1:function(){
      this.mostrar1=true;
      this.mostrar2=false;
    },
    f2:function(){
      this.mostrar2=true;
      this.mostrar1=false;
    }
  },
  beforeUpdate(){
    alert("cambiando Imagen");
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
  #dibujo{
    width:200px;
    height:200px;
  }
</style>
